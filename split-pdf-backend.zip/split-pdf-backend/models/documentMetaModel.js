const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const DocumentMetaModel = sequelize.define("DocumentMetaModel", {
    filename: {
      type: DataTypes.STRING,
      allowNull: true
    },
    image: {
      type: DataTypes.STRING,  // Changed to `image` to match your JSON key
      allowNull: true
    },
    status: {
      type: DataTypes.STRING,
      allowNull: true
    },

    excel: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },


  },
    {
      tableName: 'documents',
    });

  return DocumentMetaModel;
};
