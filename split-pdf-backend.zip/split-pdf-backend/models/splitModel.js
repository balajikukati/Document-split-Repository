const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const SplitModel = sequelize.define("SplitModel", {
    title: {
      type: DataTypes.STRING,
      allowNull: false
    },
    start_page: {
      type: DataTypes.STRING,  // Changed to `image` to match your JSON key
      allowNull: false
    },
    end_page: {
      type: DataTypes.STRING,
      allowNull: false
    },

    extracted_fields:{
     type:DataTypes.TEXT,
     allowNull: true 
    },

    content: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    document_type:
    {
      type: DataTypes.TEXT,
      allowNull: true
    },
    document_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

  },
    {
      tableName: 'split',
    });

  return SplitModel;
};
