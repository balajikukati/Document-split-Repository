const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const DocumentTypeModel = sequelize.define("DocumentTypeModel", {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
  },
  {
    tableName: 'document_type',
  });

  return DocumentTypeModel;
};
