const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
    const UserModel = sequelize.define("UserModel", {
        username: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        firstname: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        SingleDual: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        passwordstatus: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        status: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null,
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: null,
        },
    },
        {
            tableName: 'user_detail',
        });

    return UserModel;
};
