const userService = require("../services/userService");



async function createUser(req, res) {
    try {
        const userData = req.body; // Assuming the data is sent in the request body
        const newUser = await userService.createUser(userData)
        res.status(201).json(newUser);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}


async function getAllUser(req, res) {
    try {
       
        const newUser = await userService.alluser()
        res.status(201).json(newUser);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}



async function login(req, res) {
    try {
        const userData = req.body; // Assuming the data is sent in the request body
        const newUser = await userService.loginUser(userData)
        res.status(201).json(newUser);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}





module.exports = {
    createUser,
    login,
    getAllUser
}