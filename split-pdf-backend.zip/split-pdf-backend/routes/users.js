var express = require('express');
const { createUser,login, getAllUser } = require('../controllers/usercontroller');
const { verifyToken } = require('../helper/authMiddleware');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


// router.post('/createuser',verifyToken, createUser);
router.post('/createuser', createUser);
router.post('/userlogin', login);
router.get('/getuser', getAllUser);

module.exports = router;
