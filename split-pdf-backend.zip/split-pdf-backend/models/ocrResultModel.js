const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const OCRResultModel = sequelize.define("OCRResultModel", {
    page_number: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    original_content: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    corrected_content: {
      type: DataTypes.TEXT,
      allowNull: true
    },

    document_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

  },
    {
      tableName: 'ocr_result',
    });

  return OCRResultModel;
};
