'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const process = require('process');
require("dotenv").config();
const basename = path.basename(__filename);
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.json')[env];
const db = {};
console.log('i am from model :>> ',);


// const sequelize = new Sequelize("documentsplit", 'sa', "Mukesh90@", {
//   port:50340,
//   host: 'localhost', // or your database host
//   dialect: 'mssql',  // Use mssql for Microsoft SQL Server

//   logging: console.log, // Enable logging (optional)
// });

// let sequalize = new Sequelize({

//   dialect:"mssql",
//   username:"sa",
//   port:50340,
//   password:"Mukesh90@",
//   database:"documentsplit",
//   host:"localhost",
//   models:[path.join(__dirname, '../models')],
//   logging:console.log
// });


let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(process.env.DB, process.env.USER, process.env.PASSWORD, {
    port: 50340,
    host: 'localhost', // or your database host
    dialect: 'mssql',  // Use mssql for Microsoft SQL Server

    logging: console.log, // Enable logging (optional)
  });
}

fs
  .readdirSync(__dirname)
  .filter(file => {
    return (
      file.indexOf('.') !== 0 &&
      file !== basename &&
      file.slice(-3) === '.js' &&
      file.indexOf('.test.js') === -1
    );
  })
  .forEach(file => {
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

// User has many Roles
db.UserModel.hasMany(db.DocumentTypeModel, {
  as: 'document_type', // Name of the association (optional)
  foreignKey: 'userid',
  sourceKey: 'id',
});

// Role belongs to User
db.DocumentTypeModel.belongsTo(db.UserModel, {
  foreignKey: 'userid',
  targetKey: 'id',
});

// User has many Roles
db.UserModel.hasMany(db.RoleModel, {
  as: 'roles', // Name of the association (optional)
  foreignKey: 'userid',
  sourceKey: 'id',
});

// Role belongs to User
db.RoleModel.belongsTo(db.UserModel, {
  foreignKey: 'userid',
  targetKey: 'id',
});


// User has many Roles
db.UserModel.hasMany(db.StateModel, {
  as: 'state', // Name of the association (optional)
  foreignKey: 'userid',
  sourceKey: 'id',
});

// Role belongs to User
db.StateModel.belongsTo(db.UserModel, {
  foreignKey: 'userid',
  targetKey: 'id',
});

// User has many Roles
db.UserModel.hasMany(db.SubDocumentTypeModel, {
  as: 'subdocument_type', // Name of the association (optional)
  foreignKey: 'userid',
  sourceKey: 'id',
});

// Role belongs to User
db.SubDocumentTypeModel.belongsTo(db.UserModel, {
  foreignKey: 'userid',
  targetKey: 'id',
});


// User has many Roles
db.UserModel.hasMany(db.SubprocessModel, {
  as: 'subprocess', // Name of the association (optional)
  foreignKey: 'userid',
  sourceKey: 'id',
});

// Role belongs to User
db.SubDocumentTypeModel.belongsTo(db.SubprocessModel, {
  foreignKey: 'userid',
  targetKey: 'id',
});


// Document Relation
db.DocumentMetaModel.hasMany(db.OCRResultModel, {
  as: 'ocr_results', // Name of the association (optional)
  foreignKey: 'document_id',
  sourceKey: 'id',
});

// Role belongs to User
db.OCRResultModel.belongsTo(db.DocumentMetaModel, {
  foreignKey: 'document_id',
  targetKey: 'id',
});


db.DocumentMetaModel.hasMany(db.SplitModel, {
  as: 'split_documents', // Name of the association (optional)
  foreignKey: 'document_id',
  sourceKey: 'id',
});

// Role belongs to User
db.SplitModel.belongsTo(db.DocumentMetaModel, {
  foreignKey: 'document_id',
  targetKey: 'id',
});

db.DocumentMetaModel.hasMany(db.ImagePages, {
  as: 'pages', // Name of the association (optional)
  foreignKey: 'document_id',
  sourceKey: 'id',
});

// Role belongs to User
db.ImagePages.belongsTo(db.DocumentMetaModel, {
  foreignKey: 'document_id',
  targetKey: 'id',
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;




sequelize
  .sync({ force: false })
  .then((result) => {

  })
  .catch((err) => {
    console.log(err);
  });

 

module.exports = db;
