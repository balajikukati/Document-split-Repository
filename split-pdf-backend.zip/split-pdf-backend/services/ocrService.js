const db = require('../models');
const { DocumentMetaModel, OCRResultModel, SplitModel } = db;
const { Storage } = require('@google-cloud/storage');
const _ = require("lodash");

class OCRService {

    async putOcrData(data) {
        if (!Array.isArray(data) || data.length === 0) {
            throw new Error("Invalid OCR data: Expected a non-empty array.");
        }

        // Start a transaction
        const transaction = await db.sequelize.transaction();

        try {
            const recentOcrResults = _.takeRight(data, 1);

            for (const item of recentOcrResults) {
                console.log(' db.ImagePages :>> ', db.ImagePages);

                // Create DocumentMeta entry
                const documentMeta = await DocumentMetaModel.create({
                    filename: item.filename,
                    image: item.image,
                    status: "notprocessed",
                    excel: item.excel || false,
                }, { transaction });

                // Add OCR results associated with the document
                if (item.ocr_results && typeof item.ocr_results === 'object') {
                    for (const [page_number, ocrResult] of Object.entries(item.ocr_results)) {
                        console.log('objocrResult :>> ', ocrResult.original_content);
                        await OCRResultModel.create({
                            page_number,
                            original_content: ocrResult.original_content,
                            corrected_content: ocrResult.corrected_content,
                            document_id: documentMeta.id || 1,
                        }, { transaction });
                    }
                } else {
                    console.warn('Missing or invalid ocr_results for item:', item);
                }

                // Add pages associated with the document
                if (item.pages && typeof item.pages === 'object') {
                    for (const [page_number] of Object.entries(item.pages)) {
                        await db.ImagePages.create({
                            page_number: page_number || "",
                            image_url: item.pages[page_number] || "",
                            document_id: documentMeta.id || "",
                        }, { transaction });
                    }
                } else {
                    console.warn('Missing or invalid pages for item:', item);
                }

                // Add split documents associated with the document
                if (Array.isArray(item.split_documents)) {
                    for (const splitDoc of item.split_documents) {
                        const paseExtract = JSON.stringify(splitDoc.extracted_fields || {});
                        await SplitModel.create({
                            title: splitDoc.title || "",
                            start_page: splitDoc.start_page || "",
                            end_page: splitDoc.end_page || "",
                            content: splitDoc.content || "",
                            document_type: splitDoc.document_type || "",
                            extracted_fields: paseExtract,
                            document_id: documentMeta.id || 1,
                        }, { transaction });
                    }
                } else {
                    console.warn('Missing or invalid split_documents for item:', item);
                }
            }

            // Commit the transaction if everything is successful
            await transaction.commit();
        } catch (error) {
            // Roll back the transaction if an error occurs
            await transaction.rollback();
            console.error('Error during transaction:', error);
            throw error;
        }
    }





    async getDocumentWithAssociations(documentMetaId) {
        try {
            const document = await db.DocumentMetaModel.findOne({
                where: { id: documentMetaId },
                include: [
                    {
                        model: db.OCRResultModel,
                        as: 'ocr_results', // Association alias used in model definition
                    },
                    {
                        model: db.SplitModel,
                        as: 'split_documents', // Association alias used in model definition
                    },
                    // {
                    //     model: db.ImagePages,
                    //     as: 'pages', // Association alias used in model definition
                    // }
                ]
            });

            if (!document) {
                throw new Error(`Document with ID ${documentMetaId} not found.`);
            }

            return document;
        } catch (error) {
            console.error("Error fetching document with associations:", error);
            throw error;
        }
    }



    async getAllDocuments() {
        try {
            // Fetch all document meta data from the database
            const documents = await db.DocumentMetaModel.findAll();

            return documents;

        } catch (error) {
            // Log error details for debugging
            console.error("Error fetching documents from database:", error);
            throw new Error("Unable to fetch documents"); // Rethrow the error to be handled in the API route
        }
    }



    async getDocumentWithAssociationswithPage(documentMetaId) {
        try {
            const document = await db.DocumentMetaModel.findOne({
                where: { id: documentMetaId },
                include: [
                    {
                        model: db.OCRResultModel,
                        as: 'ocr_results', // Association alias used in model definition
                    },
                    {
                        model: db.SplitModel,
                        as: 'split_documents', // Association alias used in model definition
                    },
                    {
                        model: db.ImagePages,
                        as: 'pages', // Association alias used in model definition
                    }
                ]
            });

            if (!document) {
                throw new Error(`Document with ID ${documentMetaId} not found.`);
            }

            return document;
        } catch (error) {
            console.error("Error fetching document with associations:", error);
            throw error;
        }
    }

    async updateSplitOcr(data) {
        try {

            const existingRecord = await SplitModel.findByPk(data.id);

            if (!existingRecord) {

                console.log(`No record found with id ${data.id}.`);
                return;
            }

            const [updated] = await SplitModel.update(data, {
                where: { id: data.id } // Specify that we want to update the record with this id
            });


            if (updated) {
                return update
            } else {
                return `No changes made to the record with id ${data.id}.`
                //   console.log(`No changes made to the record with id ${data.id}.`);
            }
        } catch (error) {
            return error
        }
    }

    async createOcrWithStorage(data) {
        console.log('data :>> ', data.filename);
        console.log('data :>> ', await data.fileUrl);
        // console.log('object :>> ', object);

        const document = {
            filename: data.filename,
            image: await data.fileUrl,
            status: 'notprocessed'
        };


        const newDocumentMeta = await DocumentMetaModel.create(document);
        return newDocumentMeta
    }


    async deleteOCrSplit(id) {
        // Validate if 'id' is provided and is a valid type (e.g., positive integer)
        if (!id || typeof id !== 'number' || id <= 0) {
            throw new Error("Invalid 'id' provided.");
        }
    
        try {
            // Check if the record exists before attempting to delete it
            const existingRecord = await SplitModel.findOne({ where: { id } });
    
            if (!existingRecord) {
                // If no record is found, return a clear error response
                return {
                    success: false,
                    message: `OCR split with id ${id} not found.`,
                };
            }
    
            // Perform the delete operation
            const deleteStatus = await SplitModel.destroy({
                where: { id },
            });
    
            // If deleteStatus is 0, it means no rows were affected (this can happen for various reasons)
            if (deleteStatus === 0) {
                return {
                    success: false,
                    message: `Failed to delete OCR split with id ${id}.`,
                };
            }
    
            // Return a success response with the number of deleted rows (if any)
            return {
                success: true,
                message: `OCR split with id ${id} deleted successfully.`,
            };
        } catch (error) {
            // Log the error for debugging
            console.error('Error in deleteOCrSplit:', error);
    
            // Throw a more descriptive error
            throw new Error(`Unable to delete OCR split with id ${id}.`);
        }
    }
    


}

module.exports = new OCRService();
