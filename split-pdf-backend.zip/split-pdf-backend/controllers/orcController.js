const multer = require('multer');
const db = require("../models");
const mime = require('mime-types');
const { Storage } = require('@google-cloud/storage');
const ocrService = require("../services/ocrService");
const connectToMongoDB = require('../dbconnection/mondodb');


// const  mime= require('mime') ;






async function createOcr(req, res) {
  try {

    const response = await fetch("https://split-pdf-5rm6.onrender.com/get-outputs");

    console.log('response :>> ', response.ok);
    if (!response.ok) {
      throw new Error(`Failed to fetch OCR data: ${response.statusText}`);
    }

    const allOcr = await response.json();


    if (allOcr && Array.isArray(allOcr) && allOcr.length > 0) {
      // console.log('Fetched OCR data:', allOcr);

      let data = await ocrService.putOcrData(allOcr);
      res.status(200).json({ data: data, message: 'OCR data processed successfully.' });
      console.log('OCR data processed successfully');
    } else {

    }

    // Respond with a success status


  } catch (error) {
    // Log the error for internal tracking
    console.error('Error processing OCR data:', error);

    // Send a generic error response
    res.status(500).json({ error: 'Internal Server Error' });
  }
}


async function getDocumentView(req, res) {

  try {
    const documentMetaId = req.params.id;
    let response = await ocrService.getDocumentWithAssociations(documentMetaId);
    return res.status(200).json({ data: response })
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }

}


async function getDocumentViewPage(req, res) {

  try {
    const documentMetaId = req.params.id;
    let response = await ocrService.getDocumentWithAssociationswithPage(documentMetaId);
    return res.status(200).json({ data: response })
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }

}

async function getAllDoc(req, res) {
  try {
    // Call the service function to fetch the documents
    let response = await ocrService.getAllDocuments();

    // Return successful response with data
    return res.status(200).json({
      status: 'success',
      data: response
    });

  } catch (error) {
    // Log the actual error for debugging purposes
    console.error('Error fetching documents:', error);

    // Return a more descriptive error message
    return res.status(500).json({
      status: 'error',
      message: 'An error occurred while fetching documents. Please try again later.'
    });
  }
}


async function createOcrwStorage(req, res) {
  try {
    // Connect to MongoDB and retrieve service credentials
    const data = await connectToMongoDB();
    const serviceCredentials = JSON.parse(data);
    console.log('serviceCredentials :>> ', serviceCredentials);

    // Initialize Google Cloud Storage with the provided credentials
    const storage = new Storage({ credentials: serviceCredentials });
    const bucketName = "ocrimagesbucket3";
    const bucket = storage.bucket(bucketName); // Define bucket

    // Get file names and ensure it's an array
    let fileNames = req.body.fileNames;
    if (!Array.isArray(fileNames)) {
      fileNames = [fileNames]; // Convert single file name to an array if it's a string
    }

    // Get uploaded files
    const files = req.files;

    // Process each file using a for...of loop to handle async operations properly
    const response = [];
    for (const element of files) {
      const file = element;
      const buffer = file.buffer;
      const filename = file.originalname;

      // Upload file to Google Cloud Storage and get public URL
      const fileUrl = await uploadToGCS(buffer, filename, bucket);

      // Prepare request body for OCR service
      req.body.filename = filename;
      req.body.fileUrl = fileUrl;

      // Call OCR service (assuming it processes the file in storage)
      const ocrResult = await ocrService.createOcrWithStorage(req.body);
      response.push(ocrResult);
    }

    // Return the response
    return res.status(200).json({
      status: 'success',
      data: response
    });

  } catch (error) {
    console.error('Error during OCR creation:', error);
    return res.status(500).json({
      status: 'error',
      message: 'An error occurred while processing the files.'
    });
  }
}



const uploadToGCS = async (buffer, filename, bucket) => {
  try {
    const file = bucket.file(filename);
    const mimeType = mime.lookup(filename) || 'application/octet-stream'; // Default mime type

    // Upload file to bucket with proper metadata
    await file.save(buffer, {
      contentType: mimeType,
      metadata: {
        cacheControl: 'public, max-age=31536000', // Cache for a year
      },
    });

    // Make the file publicly accessible
    await file.makePublic();

    // Return the public URL for the uploaded file
    // We don't need to change the URL itself, just how it's served
    const bucketName = bucket.name;
    return `https://storage.googleapis.com/${bucketName}/${filename}`;
  } catch (error) {
    console.error('Error during file upload to GCS:', error);
    throw new Error('Failed to upload file to Google Cloud Storage');
  }
};


async function updateSplitOcr(req, res) {
  let body = req.body
  console.log('object :>> ', body);
  let data = await ocrService.updateSplitOcr(body);
  return res.status(200).json({
    status: 'success',
    data: data
  });

}

async function createOcrSplit(req, res) {

}

async function deleteOcr(req, res) {
  const id = req.params.id;

  // Validate the 'id' parameter to ensure it's a valid number (or string, depending on your use case)
  if (!id || isNaN(id) || id <= 0) {
      return res.status(400).json({
          success: false,
          message: 'Invalid OCR ID provided.',
      });
  }

  try {
      // Call the service to delete the OCR split
      const result = await ocrService.deleteOCrSplit(id);

      // If the service returns success (check the result structure)
      if (result.success) {
          return res.status(200).json({
              success: true,
              message: result.message || `OCR split with id ${id} deleted successfully.`,
          });
      }

      // If result.success is false (no record was deleted, or failed to delete)
      return res.status(404).json({
          success: false,
          message: result.message || `OCR split with id ${id} not found or could not be deleted.`,
      });

  } catch (error) {
      // Log the error for debugging
      console.error('Error in deleteOcr:', error);

      // Send a 500 error response if an unexpected error occurs
      return res.status(500).json({
          success: false,
          message: `An unexpected error occurred while deleting the OCR split with id ${id}.`,
          error: error.message, // Optional: You can remove this in production for security reasons
      });
  }
}




module.exports = {
  createOcr,
  getDocumentView,
  getAllDoc,
  getDocumentViewPage,
  createOcrwStorage,
  updateSplitOcr,
  deleteOcr
};
