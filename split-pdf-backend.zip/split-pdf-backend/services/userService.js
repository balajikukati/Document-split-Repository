const { UserModel, RoleModel, SubprocessModel, SubDocumentTypeModel, StateModel, DocumentTypeModel } = require('../models'); // Import the User model
const bcrypt = require('bcrypt');
require("dotenv").config();
const _ = require('lodash');
const { generateToken } = require('../helper/authUtils');
class UserService {
    async createUser(data) {
        try {
            console.log('Received data:', data);

            // Check if the required fields are present
            if (!data || !data.username || !data.password) {
                throw new Error('Missing required fields: username or password');
            }
            let hashSalt = process.env.HASHSALT | 10;
            let hashedPassword = await bcrypt.hash(data.password, hashSalt)
            // Create the user record
            const newUser = await UserModel.create({
                username: data.username,
                password: hashedPassword,
                firstname: data.firstname,
                SingleDual: data.SingleDual,
                passwordstatus: data.passwordstatus,
                status: data.status,
            });

            console.log('User created successfully:', newUser.id);

            // Check if roles are provided
            const roles = data.Role;
            if (roles && Array.isArray(roles)) {
                console.log('Inserting roles:', roles);
                await RoleModel.bulkCreate(roles.map(role => ({
                    name: role,
                    userid: newUser.id,
                })));
                console.log('Roles inserted successfully.');
            }

            // Check if subprocesses are provided
            const subprocesses = data.Subprocess;
            if (subprocesses && Array.isArray(subprocesses)) {
                console.log('Inserting subprocesses:', subprocesses);
                await SubprocessModel.bulkCreate(subprocesses.map(sub => ({
                    name: sub,
                    userid: newUser.id,
                })));
                console.log('Subprocesses inserted successfully.');
            }

            // Check if documentTypes are provided
            const documentTypes = data.documentType;
            if (documentTypes && Array.isArray(documentTypes)) {
                console.log('Inserting document types:', documentTypes);
                await DocumentTypeModel.bulkCreate(documentTypes.map(doc => ({
                    name: doc,
                    userid: newUser.id,
                })));
                console.log('Document Types inserted successfully.');
            }

            // Check if states are provided
            const states = data.State;
            if (states && Array.isArray(states)) {
                console.log('Inserting states:', states);
                await StateModel.bulkCreate(states.map(state => ({
                    name: state,
                    userid: newUser.id,
                })));
                console.log('States inserted successfully.');
            }

            // Check if subDocumentTypes are provided
            const subDocumentTypes = data.subDocumentType;
            if (subDocumentTypes && Array.isArray(subDocumentTypes)) {
                console.log('Inserting subdocument types:', subDocumentTypes);
                await SubDocumentTypeModel.bulkCreate(subDocumentTypes.map(doc => ({
                    name: doc,
                    userid: newUser.id,
                })));
                console.log('Subdocument Types inserted successfully.');
            }

        } catch (error) {
            console.error('Error creating user:', error);
            throw new Error(`Error creating user: ${error.message}`);
        }
    }



    async loginUser(data) {

        try {
            // Fetch the user record by username
            const user = await UserModel.findOne({ where: { username: data.username } });

            if (!user) {
                return "User does not exist"
            }

            // Compare the entered password with the stored hash
            const isPasswordValid = await bcrypt.compare(data.password, user.password);

            if (!isPasswordValid) {
                return "Password is Incorrect"
            }
            const token = generateToken(user);
            console.log('User logged in successfully');
            return { user, token }; // Or return a session token, etc.

        } catch (error) {
            console.error('Login error:', error);
            throw new Error(`Login failed: ${error.message}`);
        }
    }


    async alluser() {
        try {
            let allUser = await UserModel.findAll();
            if (allUser) {
                return allUser
            }
            return "No User"
        } catch (error) {
            return error
        }

    }


}


module.exports = new UserService()