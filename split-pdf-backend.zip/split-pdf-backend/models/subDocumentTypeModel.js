const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const SubDocumentTypeModel = sequelize.define("SubDocumentTypeModel", {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    userid: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
  },
    {
      tableName: 'sub_document_type',
    });

  return SubDocumentTypeModel;
};
