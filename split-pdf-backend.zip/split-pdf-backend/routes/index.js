var express = require('express');
const { createOcr, getDocumentView, getAllDoc, getDocumentViewPage, createOcrwStorage, updateSplitOcr, deleteOcr } = require('../controllers/orcController');
const multer = require('multer');
var router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/get-outputs', createOcr)
router.get('/get-outputs/:id', getDocumentView)
router.get('/get-outputs_page/:id', getDocumentViewPage)
router.delete('/delete-ocr/:id', deleteOcr)
router.get('/all-get-outputs/', getAllDoc)
router.post('/update-split_ocr', updateSplitOcr)
router.post('/create-ocr', upload.array('files'), createOcrwStorage)

module.exports = router;
