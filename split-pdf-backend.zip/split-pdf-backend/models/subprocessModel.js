const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const SubprocessModel = sequelize.define("SubprocessModel", {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
  },
  {
    tableName: 'subprocess',
  });

  return SubprocessModel;
};
