const { DataTypes } = require('sequelize');

module.exports = (sequelize, Sequelize) => {
  const ImagePages = sequelize.define("ImagePages", {
    image_url: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    page_number: {
      type: DataTypes.INTEGER,
      allowNull: false
    },

    document_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null,
    },
  },
  {
    tableName: 'imagepages',
  });

  return ImagePages;
};
