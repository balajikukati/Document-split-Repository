const jwt = require('jsonwebtoken');

// JWT secret key - make sure to use a strong and private key
const JWT_SECRET = process.env.JWT_SECRET || 'lt@1233'; // It’s better to load this from environment variables

// Function to generate a JWT token
function generateToken(user) {
    const payload = {
        userId: user.id,
        username: user.username,
        firstname: user.firstname,
        status: user.status,
    };

    // Generate token with a 1-hour expiration (you can adjust this as needed)
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
    return token;
}

module.exports = { generateToken };
